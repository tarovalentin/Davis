LyndonWords3 = {word[a1, a1, a2], word[a1, a1, a3], word[a1, a1, a4], 
    word[a1, a2, a2], word[a1, a2, a3], word[a1, a3, a2], word[a1, a2, a4], 
    word[a1, a4, a2], word[a1, a3, a3], word[a1, a3, a4], word[a1, a4, a3], 
    word[a1, a4, a4], word[a2, a2, a3], word[a2, a2, a4], word[a2, a3, a3], 
    word[a2, a3, a4], word[a2, a4, a3], word[a2, a4, a4], word[a3, a3, a4], 
    word[a3, a4, a4]}
