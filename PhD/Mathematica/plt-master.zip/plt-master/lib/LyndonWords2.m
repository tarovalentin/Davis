LyndonWords2 = {word[a1, a2], word[a1, a3], word[a1, a4], word[a2, a3], 
    word[a2, a4], word[a3, a4]}
