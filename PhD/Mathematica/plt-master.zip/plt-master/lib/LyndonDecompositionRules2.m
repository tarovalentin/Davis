LyndonDecompositionRules2 = {word[a1, a1] -> word[a1]^2/2, 
    word[a2, a1] -> word[a1]*word[a2] - word[a1, a2], 
    word[a2, a2] -> word[a2]^2/2}
